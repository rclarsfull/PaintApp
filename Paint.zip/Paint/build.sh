#!/bin/bash

qmake -spec macx-xcode Paint.pro
